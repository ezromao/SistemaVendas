﻿namespace SistemaVendas
{
    partial class FormVendas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVendas));
            pnl_rodape = new Panel();
            btn_GRAVARVENDA = new Button();
            btn_produto01 = new Button();
            btn_produto02 = new Button();
            btn_produto03 = new Button();
            btn_produto04 = new Button();
            btn_produto05 = new Button();
            btn_produto06 = new Button();
            btn_produto07 = new Button();
            btn_produto08 = new Button();
            btn_produto09 = new Button();
            btn_produto10 = new Button();
            btn_produto11 = new Button();
            btn_produto12 = new Button();
            btn_produto13 = new Button();
            btn_produto14 = new Button();
            btn_produto15 = new Button();
            btn_produto16 = new Button();
            btn_produto17 = new Button();
            btn_produto18 = new Button();
            btn_produto19 = new Button();
            btn_produto20 = new Button();
            label1 = new Label();
            txtbox_VENDA = new TextBox();
            btn_NOVAVENDA = new Button();
            btn_CANCELAVENDA = new Button();
            listBoxVenda = new ListBox();
            txtbox_qtd_produto01 = new TextBox();
            txtbox_qtd_produto02 = new TextBox();
            txtbox_qtd_produto03 = new TextBox();
            txtbox_qtd_produto04 = new TextBox();
            txtbox_qtd_produto05 = new TextBox();
            txtbox_qtd_produto06 = new TextBox();
            txtbox_qtd_produto07 = new TextBox();
            txtbox_qtd_produto08 = new TextBox();
            txtbox_qtd_produto09 = new TextBox();
            txtbox_qtd_produto10 = new TextBox();
            txtbox_qtd_produto20 = new TextBox();
            txtbox_qtd_produto19 = new TextBox();
            txtbox_qtd_produto18 = new TextBox();
            txtbox_qtd_produto17 = new TextBox();
            txtbox_qtd_produto16 = new TextBox();
            txtbox_qtd_produto15 = new TextBox();
            txtbox_qtd_produto14 = new TextBox();
            txtbox_qtd_produto13 = new TextBox();
            txtbox_qtd_produto12 = new TextBox();
            txtbox_qtd_produto11 = new TextBox();
            txtbox_valor_produto10 = new TextBox();
            txtbox_valor_produto09 = new TextBox();
            txtbox_valor_produto08 = new TextBox();
            txtbox_valor_produto07 = new TextBox();
            txtbox_valor_produto06 = new TextBox();
            txtbox_valor_produto05 = new TextBox();
            txtbox_valor_produto04 = new TextBox();
            txtbox_valor_produto03 = new TextBox();
            txtbox_valor_produto02 = new TextBox();
            txtbox_valor_produto01 = new TextBox();
            txtbox_valor_produto20 = new TextBox();
            txtbox_valor_produto19 = new TextBox();
            txtbox_valor_produto18 = new TextBox();
            txtbox_valor_produto17 = new TextBox();
            txtbox_valor_produto16 = new TextBox();
            txtbox_valor_produto15 = new TextBox();
            txtbox_valor_produto14 = new TextBox();
            txtbox_valor_produto13 = new TextBox();
            txtbox_valor_produto12 = new TextBox();
            txtbox_valor_produto11 = new TextBox();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label13 = new Label();
            label14 = new Label();
            label11 = new Label();
            label12 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            checkBox_PIX = new CheckBox();
            checkBox_CARTAO = new CheckBox();
            pictureBox1 = new PictureBox();
            textBox_Troco = new TextBox();
            checkBox_Dinheiro = new CheckBox();
            label3 = new Label();
            txtbox_DINHEIRO = new TextBox();
            pictureBox2 = new PictureBox();
            groupBox1 = new GroupBox();
            label24 = new Label();
            txtValorPago = new TextBox();
            btn_ApagarValorDinheiro = new Button();
            btn_25_centavos = new Button();
            btn_50_centavos = new Button();
            btn_05_centavos = new Button();
            btn_10_centavos = new Button();
            btn_100reais = new Button();
            btn_200reais = new Button();
            btn_50reais = new Button();
            btn_5reais = new Button();
            btn_20reais = new Button();
            btn_2reais = new Button();
            btn_10reais = new Button();
            btn_1real = new Button();
            btn_impressao = new Button();
            printDialog1 = new PrintDialog();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            label23 = new Label();
            textBox_TotalVenda = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // pnl_rodape
            // 
            pnl_rodape.BackColor = SystemColors.ActiveCaption;
            pnl_rodape.Dock = DockStyle.Bottom;
            pnl_rodape.Location = new Point(0, 983);
            pnl_rodape.Margin = new Padding(3, 4, 3, 4);
            pnl_rodape.Name = "pnl_rodape";
            pnl_rodape.Size = new Size(1671, 72);
            pnl_rodape.TabIndex = 0;
            // 
            // btn_GRAVARVENDA
            // 
            btn_GRAVARVENDA.BackColor = Color.Green;
            btn_GRAVARVENDA.Enabled = false;
            btn_GRAVARVENDA.Location = new Point(1050, 634);
            btn_GRAVARVENDA.Margin = new Padding(3, 4, 3, 4);
            btn_GRAVARVENDA.Name = "btn_GRAVARVENDA";
            btn_GRAVARVENDA.Size = new Size(189, 138);
            btn_GRAVARVENDA.TabIndex = 46;
            btn_GRAVARVENDA.Text = "GRAVAR VENDA";
            btn_GRAVARVENDA.UseVisualStyleBackColor = false;
            btn_GRAVARVENDA.Click += button_GRAVARVENDA_Click;
            // 
            // btn_produto01
            // 
            btn_produto01.Enabled = false;
            btn_produto01.Location = new Point(14, 120);
            btn_produto01.Margin = new Padding(3, 4, 3, 4);
            btn_produto01.Name = "btn_produto01";
            btn_produto01.Size = new Size(118, 112);
            btn_produto01.TabIndex = 1;
            btn_produto01.Text = "button01";
            btn_produto01.UseVisualStyleBackColor = true;
            btn_produto01.Click += btn_produto01_Click;
            // 
            // btn_produto02
            // 
            btn_produto02.Enabled = false;
            btn_produto02.Location = new Point(138, 120);
            btn_produto02.Margin = new Padding(3, 4, 3, 4);
            btn_produto02.Name = "btn_produto02";
            btn_produto02.Size = new Size(118, 112);
            btn_produto02.TabIndex = 2;
            btn_produto02.Text = "button02";
            btn_produto02.UseVisualStyleBackColor = true;
            btn_produto02.Click += btn_produto02_Click;
            // 
            // btn_produto03
            // 
            btn_produto03.Enabled = false;
            btn_produto03.Location = new Point(263, 120);
            btn_produto03.Margin = new Padding(3, 4, 3, 4);
            btn_produto03.Name = "btn_produto03";
            btn_produto03.Size = new Size(118, 112);
            btn_produto03.TabIndex = 3;
            btn_produto03.Text = "button03";
            btn_produto03.UseVisualStyleBackColor = true;
            btn_produto03.Click += btn_produto03_Click;
            // 
            // btn_produto04
            // 
            btn_produto04.Enabled = false;
            btn_produto04.Location = new Point(387, 120);
            btn_produto04.Margin = new Padding(3, 4, 3, 4);
            btn_produto04.Name = "btn_produto04";
            btn_produto04.Size = new Size(118, 112);
            btn_produto04.TabIndex = 4;
            btn_produto04.Text = "button04";
            btn_produto04.UseVisualStyleBackColor = true;
            btn_produto04.Click += btn_produto04_Click;
            // 
            // btn_produto05
            // 
            btn_produto05.Enabled = false;
            btn_produto05.Location = new Point(512, 120);
            btn_produto05.Margin = new Padding(3, 4, 3, 4);
            btn_produto05.Name = "btn_produto05";
            btn_produto05.Size = new Size(118, 112);
            btn_produto05.TabIndex = 5;
            btn_produto05.Text = "button05";
            btn_produto05.UseVisualStyleBackColor = true;
            btn_produto05.Click += btn_produto05_Click;
            // 
            // btn_produto06
            // 
            btn_produto06.Enabled = false;
            btn_produto06.Location = new Point(637, 120);
            btn_produto06.Margin = new Padding(3, 4, 3, 4);
            btn_produto06.Name = "btn_produto06";
            btn_produto06.Size = new Size(118, 112);
            btn_produto06.TabIndex = 6;
            btn_produto06.Text = "button06";
            btn_produto06.UseVisualStyleBackColor = true;
            btn_produto06.Click += btn_produto06_Click;
            // 
            // btn_produto07
            // 
            btn_produto07.Enabled = false;
            btn_produto07.Location = new Point(761, 120);
            btn_produto07.Margin = new Padding(3, 4, 3, 4);
            btn_produto07.Name = "btn_produto07";
            btn_produto07.Size = new Size(118, 112);
            btn_produto07.TabIndex = 7;
            btn_produto07.Text = "button07";
            btn_produto07.UseVisualStyleBackColor = true;
            btn_produto07.Click += btn_produto07_Click;
            // 
            // btn_produto08
            // 
            btn_produto08.Enabled = false;
            btn_produto08.Location = new Point(886, 120);
            btn_produto08.Margin = new Padding(3, 4, 3, 4);
            btn_produto08.Name = "btn_produto08";
            btn_produto08.Size = new Size(118, 112);
            btn_produto08.TabIndex = 8;
            btn_produto08.Text = "button08";
            btn_produto08.UseVisualStyleBackColor = true;
            btn_produto08.Click += btn_produto08_Click;
            // 
            // btn_produto09
            // 
            btn_produto09.Enabled = false;
            btn_produto09.Location = new Point(1010, 120);
            btn_produto09.Margin = new Padding(3, 4, 3, 4);
            btn_produto09.Name = "btn_produto09";
            btn_produto09.Size = new Size(118, 112);
            btn_produto09.TabIndex = 9;
            btn_produto09.Text = "button09";
            btn_produto09.UseVisualStyleBackColor = true;
            btn_produto09.Click += btn_produto09_Click;
            // 
            // btn_produto10
            // 
            btn_produto10.Enabled = false;
            btn_produto10.Location = new Point(1135, 120);
            btn_produto10.Margin = new Padding(3, 4, 3, 4);
            btn_produto10.Name = "btn_produto10";
            btn_produto10.Size = new Size(118, 112);
            btn_produto10.TabIndex = 10;
            btn_produto10.Text = "button10";
            btn_produto10.UseVisualStyleBackColor = true;
            btn_produto10.Click += btn_produto10_Click;
            // 
            // btn_produto11
            // 
            btn_produto11.Enabled = false;
            btn_produto11.Location = new Point(14, 347);
            btn_produto11.Margin = new Padding(3, 4, 3, 4);
            btn_produto11.Name = "btn_produto11";
            btn_produto11.Size = new Size(118, 112);
            btn_produto11.TabIndex = 20;
            btn_produto11.Text = "button11";
            btn_produto11.UseVisualStyleBackColor = true;
            btn_produto11.Click += btn_produto11_Click;
            // 
            // btn_produto12
            // 
            btn_produto12.Enabled = false;
            btn_produto12.Location = new Point(138, 347);
            btn_produto12.Margin = new Padding(3, 4, 3, 4);
            btn_produto12.Name = "btn_produto12";
            btn_produto12.Size = new Size(118, 112);
            btn_produto12.TabIndex = 19;
            btn_produto12.Text = "button12";
            btn_produto12.UseVisualStyleBackColor = true;
            btn_produto12.Click += btn_produto12_Click;
            // 
            // btn_produto13
            // 
            btn_produto13.Enabled = false;
            btn_produto13.Location = new Point(263, 347);
            btn_produto13.Margin = new Padding(3, 4, 3, 4);
            btn_produto13.Name = "btn_produto13";
            btn_produto13.Size = new Size(118, 112);
            btn_produto13.TabIndex = 18;
            btn_produto13.Text = "button13";
            btn_produto13.UseVisualStyleBackColor = true;
            btn_produto13.Click += btn_produto13_Click;
            // 
            // btn_produto14
            // 
            btn_produto14.Enabled = false;
            btn_produto14.Location = new Point(387, 347);
            btn_produto14.Margin = new Padding(3, 4, 3, 4);
            btn_produto14.Name = "btn_produto14";
            btn_produto14.Size = new Size(118, 112);
            btn_produto14.TabIndex = 17;
            btn_produto14.Text = "button14";
            btn_produto14.UseVisualStyleBackColor = true;
            btn_produto14.Click += btn_produto14_Click;
            // 
            // btn_produto15
            // 
            btn_produto15.Enabled = false;
            btn_produto15.Location = new Point(512, 347);
            btn_produto15.Margin = new Padding(3, 4, 3, 4);
            btn_produto15.Name = "btn_produto15";
            btn_produto15.Size = new Size(118, 112);
            btn_produto15.TabIndex = 16;
            btn_produto15.Text = "button15";
            btn_produto15.UseVisualStyleBackColor = true;
            btn_produto15.Click += btn_produto15_Click;
            // 
            // btn_produto16
            // 
            btn_produto16.Enabled = false;
            btn_produto16.Location = new Point(637, 347);
            btn_produto16.Margin = new Padding(3, 4, 3, 4);
            btn_produto16.Name = "btn_produto16";
            btn_produto16.Size = new Size(118, 112);
            btn_produto16.TabIndex = 15;
            btn_produto16.Text = "button16";
            btn_produto16.UseVisualStyleBackColor = true;
            btn_produto16.Click += btn_produto16_Click;
            // 
            // btn_produto17
            // 
            btn_produto17.Enabled = false;
            btn_produto17.Location = new Point(761, 347);
            btn_produto17.Margin = new Padding(3, 4, 3, 4);
            btn_produto17.Name = "btn_produto17";
            btn_produto17.Size = new Size(118, 112);
            btn_produto17.TabIndex = 14;
            btn_produto17.Text = "button17";
            btn_produto17.UseVisualStyleBackColor = true;
            btn_produto17.Click += btn_produto17_Click;
            // 
            // btn_produto18
            // 
            btn_produto18.Enabled = false;
            btn_produto18.Location = new Point(886, 347);
            btn_produto18.Margin = new Padding(3, 4, 3, 4);
            btn_produto18.Name = "btn_produto18";
            btn_produto18.Size = new Size(118, 112);
            btn_produto18.TabIndex = 13;
            btn_produto18.Text = "button18";
            btn_produto18.UseVisualStyleBackColor = true;
            btn_produto18.Click += btn_produto18_Click;
            // 
            // btn_produto19
            // 
            btn_produto19.Enabled = false;
            btn_produto19.Location = new Point(1010, 347);
            btn_produto19.Margin = new Padding(3, 4, 3, 4);
            btn_produto19.Name = "btn_produto19";
            btn_produto19.Size = new Size(118, 112);
            btn_produto19.TabIndex = 12;
            btn_produto19.Text = "button19";
            btn_produto19.UseVisualStyleBackColor = true;
            btn_produto19.Click += btn_produto19_Click;
            // 
            // btn_produto20
            // 
            btn_produto20.Enabled = false;
            btn_produto20.Location = new Point(1135, 347);
            btn_produto20.Margin = new Padding(3, 4, 3, 4);
            btn_produto20.Name = "btn_produto20";
            btn_produto20.Size = new Size(118, 112);
            btn_produto20.TabIndex = 11;
            btn_produto20.Text = "button20";
            btn_produto20.UseVisualStyleBackColor = true;
            btn_produto20.Click += btn_produto20_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(27, 27);
            label1.Name = "label1";
            label1.Size = new Size(112, 28);
            label1.TabIndex = 21;
            label1.Text = "VENDA Nº";
            // 
            // txtbox_VENDA
            // 
            txtbox_VENDA.Enabled = false;
            txtbox_VENDA.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtbox_VENDA.Location = new Point(17, 59);
            txtbox_VENDA.Margin = new Padding(3, 4, 3, 4);
            txtbox_VENDA.Name = "txtbox_VENDA";
            txtbox_VENDA.Size = new Size(127, 27);
            txtbox_VENDA.TabIndex = 22;
            txtbox_VENDA.TextAlign = HorizontalAlignment.Center;
            // 
            // btn_NOVAVENDA
            // 
            btn_NOVAVENDA.BackColor = Color.Green;
            btn_NOVAVENDA.Location = new Point(152, 16);
            btn_NOVAVENDA.Margin = new Padding(3, 4, 3, 4);
            btn_NOVAVENDA.Name = "btn_NOVAVENDA";
            btn_NOVAVENDA.Size = new Size(192, 79);
            btn_NOVAVENDA.TabIndex = 23;
            btn_NOVAVENDA.Text = "NOVA VENDA";
            btn_NOVAVENDA.UseVisualStyleBackColor = false;
            btn_NOVAVENDA.Click += btn_NOVAVENDA_Click;
            // 
            // btn_CANCELAVENDA
            // 
            btn_CANCELAVENDA.BackColor = Color.Red;
            btn_CANCELAVENDA.Enabled = false;
            btn_CANCELAVENDA.Location = new Point(347, 16);
            btn_CANCELAVENDA.Margin = new Padding(3, 4, 3, 4);
            btn_CANCELAVENDA.Name = "btn_CANCELAVENDA";
            btn_CANCELAVENDA.Size = new Size(192, 79);
            btn_CANCELAVENDA.TabIndex = 24;
            btn_CANCELAVENDA.Text = "CANCELA VENDA";
            btn_CANCELAVENDA.UseVisualStyleBackColor = false;
            btn_CANCELAVENDA.Click += button_CANCELAVENDA_Click;
            // 
            // listBoxVenda
            // 
            listBoxVenda.BackColor = SystemColors.InactiveCaption;
            listBoxVenda.Font = new Font("Arial Narrow", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            listBoxVenda.FormattingEnabled = true;
            listBoxVenda.ItemHeight = 16;
            listBoxVenda.Location = new Point(1267, 514);
            listBoxVenda.Margin = new Padding(3, 4, 3, 4);
            listBoxVenda.Name = "listBoxVenda";
            listBoxVenda.Size = new Size(382, 276);
            listBoxVenda.TabIndex = 46;
            // 
            // txtbox_qtd_produto01
            // 
            txtbox_qtd_produto01.Enabled = false;
            txtbox_qtd_produto01.Location = new Point(48, 240);
            txtbox_qtd_produto01.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto01.Name = "txtbox_qtd_produto01";
            txtbox_qtd_produto01.Size = new Size(70, 27);
            txtbox_qtd_produto01.TabIndex = 26;
            txtbox_qtd_produto01.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto02
            // 
            txtbox_qtd_produto02.Enabled = false;
            txtbox_qtd_produto02.Location = new Point(173, 240);
            txtbox_qtd_produto02.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto02.Name = "txtbox_qtd_produto02";
            txtbox_qtd_produto02.Size = new Size(70, 27);
            txtbox_qtd_produto02.TabIndex = 27;
            txtbox_qtd_produto02.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto03
            // 
            txtbox_qtd_produto03.Enabled = false;
            txtbox_qtd_produto03.Location = new Point(297, 240);
            txtbox_qtd_produto03.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto03.Name = "txtbox_qtd_produto03";
            txtbox_qtd_produto03.Size = new Size(70, 27);
            txtbox_qtd_produto03.TabIndex = 28;
            txtbox_qtd_produto03.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto04
            // 
            txtbox_qtd_produto04.Enabled = false;
            txtbox_qtd_produto04.Location = new Point(422, 240);
            txtbox_qtd_produto04.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto04.Name = "txtbox_qtd_produto04";
            txtbox_qtd_produto04.Size = new Size(70, 27);
            txtbox_qtd_produto04.TabIndex = 29;
            txtbox_qtd_produto04.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto05
            // 
            txtbox_qtd_produto05.Enabled = false;
            txtbox_qtd_produto05.Location = new Point(546, 240);
            txtbox_qtd_produto05.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto05.Name = "txtbox_qtd_produto05";
            txtbox_qtd_produto05.Size = new Size(70, 27);
            txtbox_qtd_produto05.TabIndex = 30;
            txtbox_qtd_produto05.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto06
            // 
            txtbox_qtd_produto06.Enabled = false;
            txtbox_qtd_produto06.Location = new Point(671, 240);
            txtbox_qtd_produto06.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto06.Name = "txtbox_qtd_produto06";
            txtbox_qtd_produto06.Size = new Size(70, 27);
            txtbox_qtd_produto06.TabIndex = 31;
            txtbox_qtd_produto06.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto07
            // 
            txtbox_qtd_produto07.Enabled = false;
            txtbox_qtd_produto07.Location = new Point(795, 240);
            txtbox_qtd_produto07.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto07.Name = "txtbox_qtd_produto07";
            txtbox_qtd_produto07.Size = new Size(70, 27);
            txtbox_qtd_produto07.TabIndex = 32;
            txtbox_qtd_produto07.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto08
            // 
            txtbox_qtd_produto08.Enabled = false;
            txtbox_qtd_produto08.Location = new Point(920, 240);
            txtbox_qtd_produto08.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto08.Name = "txtbox_qtd_produto08";
            txtbox_qtd_produto08.Size = new Size(70, 27);
            txtbox_qtd_produto08.TabIndex = 33;
            txtbox_qtd_produto08.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto09
            // 
            txtbox_qtd_produto09.Enabled = false;
            txtbox_qtd_produto09.Location = new Point(1045, 240);
            txtbox_qtd_produto09.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto09.Name = "txtbox_qtd_produto09";
            txtbox_qtd_produto09.Size = new Size(70, 27);
            txtbox_qtd_produto09.TabIndex = 34;
            txtbox_qtd_produto09.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto10
            // 
            txtbox_qtd_produto10.Enabled = false;
            txtbox_qtd_produto10.Location = new Point(1169, 240);
            txtbox_qtd_produto10.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto10.Name = "txtbox_qtd_produto10";
            txtbox_qtd_produto10.Size = new Size(70, 27);
            txtbox_qtd_produto10.TabIndex = 35;
            txtbox_qtd_produto10.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto20
            // 
            txtbox_qtd_produto20.Enabled = false;
            txtbox_qtd_produto20.Location = new Point(1169, 467);
            txtbox_qtd_produto20.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto20.Name = "txtbox_qtd_produto20";
            txtbox_qtd_produto20.Size = new Size(70, 27);
            txtbox_qtd_produto20.TabIndex = 45;
            txtbox_qtd_produto20.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto19
            // 
            txtbox_qtd_produto19.Enabled = false;
            txtbox_qtd_produto19.Location = new Point(1045, 467);
            txtbox_qtd_produto19.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto19.Name = "txtbox_qtd_produto19";
            txtbox_qtd_produto19.Size = new Size(70, 27);
            txtbox_qtd_produto19.TabIndex = 44;
            txtbox_qtd_produto19.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto18
            // 
            txtbox_qtd_produto18.Enabled = false;
            txtbox_qtd_produto18.Location = new Point(920, 467);
            txtbox_qtd_produto18.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto18.Name = "txtbox_qtd_produto18";
            txtbox_qtd_produto18.Size = new Size(70, 27);
            txtbox_qtd_produto18.TabIndex = 43;
            txtbox_qtd_produto18.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto17
            // 
            txtbox_qtd_produto17.Enabled = false;
            txtbox_qtd_produto17.Location = new Point(795, 467);
            txtbox_qtd_produto17.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto17.Name = "txtbox_qtd_produto17";
            txtbox_qtd_produto17.Size = new Size(70, 27);
            txtbox_qtd_produto17.TabIndex = 42;
            txtbox_qtd_produto17.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto16
            // 
            txtbox_qtd_produto16.Enabled = false;
            txtbox_qtd_produto16.Location = new Point(671, 467);
            txtbox_qtd_produto16.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto16.Name = "txtbox_qtd_produto16";
            txtbox_qtd_produto16.Size = new Size(70, 27);
            txtbox_qtd_produto16.TabIndex = 41;
            txtbox_qtd_produto16.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto15
            // 
            txtbox_qtd_produto15.Enabled = false;
            txtbox_qtd_produto15.Location = new Point(546, 467);
            txtbox_qtd_produto15.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto15.Name = "txtbox_qtd_produto15";
            txtbox_qtd_produto15.Size = new Size(70, 27);
            txtbox_qtd_produto15.TabIndex = 40;
            txtbox_qtd_produto15.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto14
            // 
            txtbox_qtd_produto14.Enabled = false;
            txtbox_qtd_produto14.Location = new Point(422, 467);
            txtbox_qtd_produto14.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto14.Name = "txtbox_qtd_produto14";
            txtbox_qtd_produto14.Size = new Size(70, 27);
            txtbox_qtd_produto14.TabIndex = 39;
            txtbox_qtd_produto14.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto13
            // 
            txtbox_qtd_produto13.Enabled = false;
            txtbox_qtd_produto13.Location = new Point(297, 467);
            txtbox_qtd_produto13.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto13.Name = "txtbox_qtd_produto13";
            txtbox_qtd_produto13.Size = new Size(70, 27);
            txtbox_qtd_produto13.TabIndex = 38;
            txtbox_qtd_produto13.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto12
            // 
            txtbox_qtd_produto12.Enabled = false;
            txtbox_qtd_produto12.Location = new Point(173, 467);
            txtbox_qtd_produto12.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto12.Name = "txtbox_qtd_produto12";
            txtbox_qtd_produto12.Size = new Size(70, 27);
            txtbox_qtd_produto12.TabIndex = 37;
            txtbox_qtd_produto12.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_qtd_produto11
            // 
            txtbox_qtd_produto11.Enabled = false;
            txtbox_qtd_produto11.Location = new Point(48, 467);
            txtbox_qtd_produto11.Margin = new Padding(3, 4, 3, 4);
            txtbox_qtd_produto11.Name = "txtbox_qtd_produto11";
            txtbox_qtd_produto11.Size = new Size(70, 27);
            txtbox_qtd_produto11.TabIndex = 36;
            txtbox_qtd_produto11.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto10
            // 
            txtbox_valor_produto10.Enabled = false;
            txtbox_valor_produto10.Location = new Point(1135, 279);
            txtbox_valor_produto10.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto10.Name = "txtbox_valor_produto10";
            txtbox_valor_produto10.Size = new Size(117, 27);
            txtbox_valor_produto10.TabIndex = 55;
            txtbox_valor_produto10.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto09
            // 
            txtbox_valor_produto09.Enabled = false;
            txtbox_valor_produto09.Location = new Point(1010, 279);
            txtbox_valor_produto09.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto09.Name = "txtbox_valor_produto09";
            txtbox_valor_produto09.Size = new Size(117, 27);
            txtbox_valor_produto09.TabIndex = 54;
            txtbox_valor_produto09.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto08
            // 
            txtbox_valor_produto08.Enabled = false;
            txtbox_valor_produto08.Location = new Point(886, 279);
            txtbox_valor_produto08.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto08.Name = "txtbox_valor_produto08";
            txtbox_valor_produto08.Size = new Size(117, 27);
            txtbox_valor_produto08.TabIndex = 53;
            txtbox_valor_produto08.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto07
            // 
            txtbox_valor_produto07.Enabled = false;
            txtbox_valor_produto07.Location = new Point(761, 279);
            txtbox_valor_produto07.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto07.Name = "txtbox_valor_produto07";
            txtbox_valor_produto07.Size = new Size(117, 27);
            txtbox_valor_produto07.TabIndex = 52;
            txtbox_valor_produto07.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto06
            // 
            txtbox_valor_produto06.Enabled = false;
            txtbox_valor_produto06.Location = new Point(637, 279);
            txtbox_valor_produto06.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto06.Name = "txtbox_valor_produto06";
            txtbox_valor_produto06.Size = new Size(117, 27);
            txtbox_valor_produto06.TabIndex = 51;
            txtbox_valor_produto06.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto05
            // 
            txtbox_valor_produto05.Enabled = false;
            txtbox_valor_produto05.Location = new Point(512, 279);
            txtbox_valor_produto05.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto05.Name = "txtbox_valor_produto05";
            txtbox_valor_produto05.Size = new Size(117, 27);
            txtbox_valor_produto05.TabIndex = 50;
            txtbox_valor_produto05.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto04
            // 
            txtbox_valor_produto04.Enabled = false;
            txtbox_valor_produto04.Location = new Point(387, 279);
            txtbox_valor_produto04.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto04.Name = "txtbox_valor_produto04";
            txtbox_valor_produto04.Size = new Size(117, 27);
            txtbox_valor_produto04.TabIndex = 49;
            txtbox_valor_produto04.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto03
            // 
            txtbox_valor_produto03.Enabled = false;
            txtbox_valor_produto03.Location = new Point(263, 279);
            txtbox_valor_produto03.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto03.Name = "txtbox_valor_produto03";
            txtbox_valor_produto03.Size = new Size(117, 27);
            txtbox_valor_produto03.TabIndex = 48;
            txtbox_valor_produto03.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto02
            // 
            txtbox_valor_produto02.Enabled = false;
            txtbox_valor_produto02.Location = new Point(138, 279);
            txtbox_valor_produto02.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto02.Name = "txtbox_valor_produto02";
            txtbox_valor_produto02.Size = new Size(117, 27);
            txtbox_valor_produto02.TabIndex = 47;
            txtbox_valor_produto02.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto01
            // 
            txtbox_valor_produto01.Enabled = false;
            txtbox_valor_produto01.Location = new Point(14, 279);
            txtbox_valor_produto01.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto01.Name = "txtbox_valor_produto01";
            txtbox_valor_produto01.Size = new Size(117, 27);
            txtbox_valor_produto01.TabIndex = 46;
            txtbox_valor_produto01.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto20
            // 
            txtbox_valor_produto20.Enabled = false;
            txtbox_valor_produto20.Location = new Point(1135, 505);
            txtbox_valor_produto20.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto20.Name = "txtbox_valor_produto20";
            txtbox_valor_produto20.Size = new Size(117, 27);
            txtbox_valor_produto20.TabIndex = 65;
            txtbox_valor_produto20.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto19
            // 
            txtbox_valor_produto19.Enabled = false;
            txtbox_valor_produto19.Location = new Point(1010, 505);
            txtbox_valor_produto19.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto19.Name = "txtbox_valor_produto19";
            txtbox_valor_produto19.Size = new Size(117, 27);
            txtbox_valor_produto19.TabIndex = 64;
            txtbox_valor_produto19.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto18
            // 
            txtbox_valor_produto18.Enabled = false;
            txtbox_valor_produto18.Location = new Point(886, 505);
            txtbox_valor_produto18.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto18.Name = "txtbox_valor_produto18";
            txtbox_valor_produto18.Size = new Size(117, 27);
            txtbox_valor_produto18.TabIndex = 63;
            txtbox_valor_produto18.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto17
            // 
            txtbox_valor_produto17.Enabled = false;
            txtbox_valor_produto17.Location = new Point(761, 505);
            txtbox_valor_produto17.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto17.Name = "txtbox_valor_produto17";
            txtbox_valor_produto17.Size = new Size(117, 27);
            txtbox_valor_produto17.TabIndex = 62;
            txtbox_valor_produto17.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto16
            // 
            txtbox_valor_produto16.Enabled = false;
            txtbox_valor_produto16.Location = new Point(637, 505);
            txtbox_valor_produto16.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto16.Name = "txtbox_valor_produto16";
            txtbox_valor_produto16.Size = new Size(117, 27);
            txtbox_valor_produto16.TabIndex = 61;
            txtbox_valor_produto16.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto15
            // 
            txtbox_valor_produto15.Enabled = false;
            txtbox_valor_produto15.Location = new Point(512, 505);
            txtbox_valor_produto15.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto15.Name = "txtbox_valor_produto15";
            txtbox_valor_produto15.Size = new Size(117, 27);
            txtbox_valor_produto15.TabIndex = 60;
            txtbox_valor_produto15.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto14
            // 
            txtbox_valor_produto14.Enabled = false;
            txtbox_valor_produto14.Location = new Point(387, 505);
            txtbox_valor_produto14.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto14.Name = "txtbox_valor_produto14";
            txtbox_valor_produto14.Size = new Size(117, 27);
            txtbox_valor_produto14.TabIndex = 59;
            txtbox_valor_produto14.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto13
            // 
            txtbox_valor_produto13.Enabled = false;
            txtbox_valor_produto13.Location = new Point(263, 505);
            txtbox_valor_produto13.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto13.Name = "txtbox_valor_produto13";
            txtbox_valor_produto13.Size = new Size(117, 27);
            txtbox_valor_produto13.TabIndex = 58;
            txtbox_valor_produto13.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto12
            // 
            txtbox_valor_produto12.Enabled = false;
            txtbox_valor_produto12.Location = new Point(138, 505);
            txtbox_valor_produto12.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto12.Name = "txtbox_valor_produto12";
            txtbox_valor_produto12.Size = new Size(117, 27);
            txtbox_valor_produto12.TabIndex = 57;
            txtbox_valor_produto12.TextAlign = HorizontalAlignment.Center;
            // 
            // txtbox_valor_produto11
            // 
            txtbox_valor_produto11.Enabled = false;
            txtbox_valor_produto11.Location = new Point(14, 505);
            txtbox_valor_produto11.Margin = new Padding(3, 4, 3, 4);
            txtbox_valor_produto11.Name = "txtbox_valor_produto11";
            txtbox_valor_produto11.Size = new Size(117, 27);
            txtbox_valor_produto11.TabIndex = 56;
            txtbox_valor_produto11.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(18, 243);
            label2.Name = "label2";
            label2.Size = new Size(25, 28);
            label2.TabIndex = 66;
            label2.Text = "X";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(143, 243);
            label4.Name = "label4";
            label4.Size = new Size(25, 28);
            label4.TabIndex = 67;
            label4.Text = "X";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(392, 243);
            label5.Name = "label5";
            label5.Size = new Size(25, 28);
            label5.TabIndex = 69;
            label5.Text = "X";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(267, 243);
            label6.Name = "label6";
            label6.Size = new Size(25, 28);
            label6.TabIndex = 68;
            label6.Text = "X";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(890, 243);
            label7.Name = "label7";
            label7.Size = new Size(25, 28);
            label7.TabIndex = 73;
            label7.Text = "X";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(766, 243);
            label8.Name = "label8";
            label8.Size = new Size(25, 28);
            label8.TabIndex = 72;
            label8.Text = "X";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(641, 243);
            label9.Name = "label9";
            label9.Size = new Size(25, 28);
            label9.TabIndex = 71;
            label9.Text = "X";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(517, 243);
            label10.Name = "label10";
            label10.Size = new Size(25, 28);
            label10.TabIndex = 70;
            label10.Text = "X";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(1139, 243);
            label13.Name = "label13";
            label13.Size = new Size(25, 28);
            label13.TabIndex = 75;
            label13.Text = "X";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(1015, 243);
            label14.Name = "label14";
            label14.Size = new Size(25, 28);
            label14.TabIndex = 74;
            label14.Text = "X";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(1139, 467);
            label11.Name = "label11";
            label11.Size = new Size(25, 28);
            label11.TabIndex = 85;
            label11.Text = "X";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(1015, 467);
            label12.Name = "label12";
            label12.Size = new Size(25, 28);
            label12.TabIndex = 84;
            label12.Text = "X";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(890, 467);
            label15.Name = "label15";
            label15.Size = new Size(25, 28);
            label15.TabIndex = 83;
            label15.Text = "X";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label16.Location = new Point(766, 467);
            label16.Name = "label16";
            label16.Size = new Size(25, 28);
            label16.TabIndex = 82;
            label16.Text = "X";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label17.Location = new Point(641, 467);
            label17.Name = "label17";
            label17.Size = new Size(25, 28);
            label17.TabIndex = 81;
            label17.Text = "X";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label18.Location = new Point(517, 467);
            label18.Name = "label18";
            label18.Size = new Size(25, 28);
            label18.TabIndex = 80;
            label18.Text = "X";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label19.Location = new Point(392, 467);
            label19.Name = "label19";
            label19.Size = new Size(25, 28);
            label19.TabIndex = 79;
            label19.Text = "X";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label20.Location = new Point(267, 467);
            label20.Name = "label20";
            label20.Size = new Size(25, 28);
            label20.TabIndex = 78;
            label20.Text = "X";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label21.Location = new Point(143, 467);
            label21.Name = "label21";
            label21.Size = new Size(25, 28);
            label21.TabIndex = 77;
            label21.Text = "X";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label22.Location = new Point(18, 467);
            label22.Name = "label22";
            label22.Size = new Size(25, 28);
            label22.TabIndex = 76;
            label22.Text = "X";
            // 
            // checkBox_PIX
            // 
            checkBox_PIX.AutoSize = true;
            checkBox_PIX.Enabled = false;
            checkBox_PIX.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox_PIX.Location = new Point(10, 41);
            checkBox_PIX.Margin = new Padding(3, 4, 3, 4);
            checkBox_PIX.Name = "checkBox_PIX";
            checkBox_PIX.Size = new Size(65, 32);
            checkBox_PIX.TabIndex = 51;
            checkBox_PIX.Text = "PIX";
            checkBox_PIX.UseVisualStyleBackColor = true;
            checkBox_PIX.CheckedChanged += checkBox_PIX_CheckedChanged;
            // 
            // checkBox_CARTAO
            // 
            checkBox_CARTAO.AutoSize = true;
            checkBox_CARTAO.Enabled = false;
            checkBox_CARTAO.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox_CARTAO.Location = new Point(208, 41);
            checkBox_CARTAO.Margin = new Padding(3, 4, 3, 4);
            checkBox_CARTAO.Name = "checkBox_CARTAO";
            checkBox_CARTAO.Size = new Size(113, 32);
            checkBox_CARTAO.TabIndex = 53;
            checkBox_CARTAO.Text = "CARTÃO";
            checkBox_CARTAO.UseVisualStyleBackColor = true;
            checkBox_CARTAO.CheckedChanged += checkBox_CARTAO_CheckedChanged_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(10, 83);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 127);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 50;
            pictureBox1.TabStop = false;
            // 
            // textBox_Troco
            // 
            textBox_Troco.BackColor = SystemColors.ControlLightLight;
            textBox_Troco.Enabled = false;
            textBox_Troco.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox_Troco.Location = new Point(464, 247);
            textBox_Troco.Margin = new Padding(3, 4, 3, 4);
            textBox_Troco.Name = "textBox_Troco";
            textBox_Troco.Size = new Size(127, 27);
            textBox_Troco.TabIndex = 48;
            textBox_Troco.TextAlign = HorizontalAlignment.Center;
            // 
            // checkBox_Dinheiro
            // 
            checkBox_Dinheiro.AutoSize = true;
            checkBox_Dinheiro.Enabled = false;
            checkBox_Dinheiro.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox_Dinheiro.Location = new Point(470, 40);
            checkBox_Dinheiro.Margin = new Padding(3, 4, 3, 4);
            checkBox_Dinheiro.Name = "checkBox_Dinheiro";
            checkBox_Dinheiro.Size = new Size(131, 32);
            checkBox_Dinheiro.TabIndex = 54;
            checkBox_Dinheiro.Text = "DINHEIRO";
            checkBox_Dinheiro.UseVisualStyleBackColor = true;
            checkBox_Dinheiro.CheckedChanged += checkBox_Dinheiro_CheckedChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(486, 215);
            label3.Name = "label3";
            label3.Size = new Size(79, 28);
            label3.TabIndex = 47;
            label3.Text = "TROCO";
            // 
            // txtbox_DINHEIRO
            // 
            txtbox_DINHEIRO.BackColor = SystemColors.ControlLightLight;
            txtbox_DINHEIRO.Enabled = false;
            txtbox_DINHEIRO.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtbox_DINHEIRO.Location = new Point(464, 81);
            txtbox_DINHEIRO.Margin = new Padding(3, 4, 3, 4);
            txtbox_DINHEIRO.Name = "txtbox_DINHEIRO";
            txtbox_DINHEIRO.Size = new Size(127, 27);
            txtbox_DINHEIRO.TabIndex = 46;
            txtbox_DINHEIRO.TextAlign = HorizontalAlignment.Center;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(208, 83);
            pictureBox2.Margin = new Padding(3, 4, 3, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(176, 127);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 52;
            pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label24);
            groupBox1.Controls.Add(txtValorPago);
            groupBox1.Controls.Add(btn_ApagarValorDinheiro);
            groupBox1.Controls.Add(btn_25_centavos);
            groupBox1.Controls.Add(btn_50_centavos);
            groupBox1.Controls.Add(btn_05_centavos);
            groupBox1.Controls.Add(btn_10_centavos);
            groupBox1.Controls.Add(btn_100reais);
            groupBox1.Controls.Add(btn_200reais);
            groupBox1.Controls.Add(btn_50reais);
            groupBox1.Controls.Add(btn_5reais);
            groupBox1.Controls.Add(btn_20reais);
            groupBox1.Controls.Add(btn_2reais);
            groupBox1.Controls.Add(btn_10reais);
            groupBox1.Controls.Add(btn_1real);
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Controls.Add(txtbox_DINHEIRO);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(checkBox_Dinheiro);
            groupBox1.Controls.Add(textBox_Troco);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(checkBox_CARTAO);
            groupBox1.Controls.Add(checkBox_PIX);
            groupBox1.Location = new Point(14, 580);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(1013, 293);
            groupBox1.TabIndex = 86;
            groupBox1.TabStop = false;
            groupBox1.Text = "FORMA DE PAGAMENTO";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label24.Location = new Point(457, 133);
            label24.Name = "label24";
            label24.Size = new Size(142, 28);
            label24.TabIndex = 68;
            label24.Text = "VALOR TOTAL";
            // 
            // txtValorPago
            // 
            txtValorPago.BackColor = SystemColors.ControlLightLight;
            txtValorPago.Enabled = false;
            txtValorPago.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtValorPago.Location = new Point(464, 165);
            txtValorPago.Margin = new Padding(3, 4, 3, 4);
            txtValorPago.Name = "txtValorPago";
            txtValorPago.Size = new Size(127, 27);
            txtValorPago.TabIndex = 69;
            txtValorPago.TextAlign = HorizontalAlignment.Center;
            // 
            // btn_ApagarValorDinheiro
            // 
            btn_ApagarValorDinheiro.Enabled = false;
            btn_ApagarValorDinheiro.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_ApagarValorDinheiro.Location = new Point(656, 140);
            btn_ApagarValorDinheiro.Name = "btn_ApagarValorDinheiro";
            btn_ApagarValorDinheiro.Size = new Size(150, 111);
            btn_ApagarValorDinheiro.TabIndex = 67;
            btn_ApagarValorDinheiro.Text = "Apagar Valor Dinheiro";
            btn_ApagarValorDinheiro.UseVisualStyleBackColor = true;
            btn_ApagarValorDinheiro.Click += btn_ApagarValorDinheiro_Click;
            // 
            // btn_25_centavos
            // 
            btn_25_centavos.Enabled = false;
            btn_25_centavos.Location = new Point(734, 21);
            btn_25_centavos.Name = "btn_25_centavos";
            btn_25_centavos.Size = new Size(72, 53);
            btn_25_centavos.TabIndex = 66;
            btn_25_centavos.Text = "R$0,25";
            btn_25_centavos.UseVisualStyleBackColor = true;
            btn_25_centavos.Click += btn_25_centavos_Click;
            // 
            // btn_50_centavos
            // 
            btn_50_centavos.Enabled = false;
            btn_50_centavos.Location = new Point(734, 81);
            btn_50_centavos.Name = "btn_50_centavos";
            btn_50_centavos.Size = new Size(72, 53);
            btn_50_centavos.TabIndex = 65;
            btn_50_centavos.Text = "R$0,50";
            btn_50_centavos.UseVisualStyleBackColor = true;
            btn_50_centavos.Click += btn_50_centavos_Click;
            // 
            // btn_05_centavos
            // 
            btn_05_centavos.Enabled = false;
            btn_05_centavos.Location = new Point(656, 21);
            btn_05_centavos.Name = "btn_05_centavos";
            btn_05_centavos.Size = new Size(72, 53);
            btn_05_centavos.TabIndex = 64;
            btn_05_centavos.Text = "R$0,05";
            btn_05_centavos.UseVisualStyleBackColor = true;
            btn_05_centavos.Click += btn_05_centavos_Click;
            // 
            // btn_10_centavos
            // 
            btn_10_centavos.Enabled = false;
            btn_10_centavos.Location = new Point(656, 81);
            btn_10_centavos.Name = "btn_10_centavos";
            btn_10_centavos.Size = new Size(72, 53);
            btn_10_centavos.TabIndex = 63;
            btn_10_centavos.Text = "R$0,10";
            btn_10_centavos.UseVisualStyleBackColor = true;
            btn_10_centavos.Click += btn_10_centavos_Click;
            // 
            // btn_100reais
            // 
            btn_100reais.Enabled = false;
            btn_100reais.Location = new Point(815, 197);
            btn_100reais.Name = "btn_100reais";
            btn_100reais.Size = new Size(72, 53);
            btn_100reais.TabIndex = 62;
            btn_100reais.Text = "R$ 100,00";
            btn_100reais.UseVisualStyleBackColor = true;
            btn_100reais.Click += btn_100reais_Click;
            // 
            // btn_200reais
            // 
            btn_200reais.Enabled = false;
            btn_200reais.Location = new Point(894, 197);
            btn_200reais.Name = "btn_200reais";
            btn_200reais.Size = new Size(72, 53);
            btn_200reais.TabIndex = 61;
            btn_200reais.Text = "R$ 200,00";
            btn_200reais.UseVisualStyleBackColor = true;
            btn_200reais.Click += btn_200reais_Click;
            // 
            // btn_50reais
            // 
            btn_50reais.Enabled = false;
            btn_50reais.Location = new Point(894, 139);
            btn_50reais.Name = "btn_50reais";
            btn_50reais.Size = new Size(72, 53);
            btn_50reais.TabIndex = 60;
            btn_50reais.Text = "R$ 50,00";
            btn_50reais.UseVisualStyleBackColor = true;
            btn_50reais.Click += btn_50reais_Click;
            // 
            // btn_5reais
            // 
            btn_5reais.Enabled = false;
            btn_5reais.Location = new Point(894, 21);
            btn_5reais.Name = "btn_5reais";
            btn_5reais.Size = new Size(72, 53);
            btn_5reais.TabIndex = 59;
            btn_5reais.Text = "R$   5,00";
            btn_5reais.UseVisualStyleBackColor = true;
            btn_5reais.Click += btn_5reais_Click;
            // 
            // btn_20reais
            // 
            btn_20reais.Enabled = false;
            btn_20reais.Location = new Point(815, 139);
            btn_20reais.Name = "btn_20reais";
            btn_20reais.Size = new Size(72, 53);
            btn_20reais.TabIndex = 58;
            btn_20reais.Text = "R$ 20,00";
            btn_20reais.UseVisualStyleBackColor = true;
            btn_20reais.Click += btn_20reais_Click;
            // 
            // btn_2reais
            // 
            btn_2reais.Enabled = false;
            btn_2reais.Location = new Point(815, 80);
            btn_2reais.Name = "btn_2reais";
            btn_2reais.Size = new Size(72, 53);
            btn_2reais.TabIndex = 57;
            btn_2reais.Text = "R$   2,00";
            btn_2reais.UseVisualStyleBackColor = true;
            btn_2reais.Click += btn_2reais_Click;
            // 
            // btn_10reais
            // 
            btn_10reais.Enabled = false;
            btn_10reais.Location = new Point(894, 80);
            btn_10reais.Name = "btn_10reais";
            btn_10reais.Size = new Size(72, 53);
            btn_10reais.TabIndex = 56;
            btn_10reais.Text = "R$ 10,00";
            btn_10reais.UseVisualStyleBackColor = true;
            btn_10reais.Click += btn_10reais_Click;
            // 
            // btn_1real
            // 
            btn_1real.Enabled = false;
            btn_1real.Location = new Point(815, 20);
            btn_1real.Name = "btn_1real";
            btn_1real.Size = new Size(72, 53);
            btn_1real.TabIndex = 55;
            btn_1real.Text = "R$   1,00";
            btn_1real.UseVisualStyleBackColor = true;
            btn_1real.Click += btn_1real_Click;
            // 
            // btn_impressao
            // 
            btn_impressao.BackColor = Color.SteelBlue;
            btn_impressao.Enabled = false;
            btn_impressao.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_impressao.Location = new Point(1267, 793);
            btn_impressao.Margin = new Padding(3, 4, 3, 4);
            btn_impressao.Name = "btn_impressao";
            btn_impressao.Size = new Size(382, 39);
            btn_impressao.TabIndex = 87;
            btn_impressao.Text = "IMPRIMIR";
            btn_impressao.UseVisualStyleBackColor = false;
            btn_impressao.Click += btn_impressao_Click;
            // 
            // printDialog1
            // 
            printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label23.Location = new Point(965, 52);
            label23.Name = "label23";
            label23.Size = new Size(103, 28);
            label23.TabIndex = 88;
            label23.Text = "TOTAL R$";
            // 
            // textBox_TotalVenda
            // 
            textBox_TotalVenda.BackColor = SystemColors.ControlLightLight;
            textBox_TotalVenda.Enabled = false;
            textBox_TotalVenda.Font = new Font("Arial Narrow", 36F, FontStyle.Bold, GraphicsUnit.Point);
            textBox_TotalVenda.ForeColor = SystemColors.ControlLightLight;
            textBox_TotalVenda.Location = new Point(1074, 27);
            textBox_TotalVenda.Margin = new Padding(3, 4, 3, 4);
            textBox_TotalVenda.Name = "textBox_TotalVenda";
            textBox_TotalVenda.Size = new Size(175, 76);
            textBox_TotalVenda.TabIndex = 89;
            textBox_TotalVenda.TextAlign = HorizontalAlignment.Center;
            // 
            // FormVendas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1671, 1055);
            Controls.Add(label23);
            Controls.Add(textBox_TotalVenda);
            Controls.Add(btn_impressao);
            Controls.Add(groupBox1);
            Controls.Add(btn_GRAVARVENDA);
            Controls.Add(listBoxVenda);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label15);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(label22);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(txtbox_valor_produto20);
            Controls.Add(txtbox_valor_produto19);
            Controls.Add(txtbox_valor_produto18);
            Controls.Add(txtbox_valor_produto17);
            Controls.Add(txtbox_valor_produto16);
            Controls.Add(txtbox_valor_produto15);
            Controls.Add(txtbox_valor_produto14);
            Controls.Add(txtbox_valor_produto13);
            Controls.Add(txtbox_valor_produto12);
            Controls.Add(txtbox_valor_produto11);
            Controls.Add(txtbox_valor_produto10);
            Controls.Add(txtbox_valor_produto09);
            Controls.Add(txtbox_valor_produto08);
            Controls.Add(txtbox_valor_produto07);
            Controls.Add(txtbox_valor_produto06);
            Controls.Add(txtbox_valor_produto05);
            Controls.Add(txtbox_valor_produto04);
            Controls.Add(txtbox_valor_produto03);
            Controls.Add(txtbox_valor_produto02);
            Controls.Add(txtbox_valor_produto01);
            Controls.Add(txtbox_qtd_produto20);
            Controls.Add(txtbox_qtd_produto19);
            Controls.Add(txtbox_qtd_produto18);
            Controls.Add(txtbox_qtd_produto17);
            Controls.Add(txtbox_qtd_produto16);
            Controls.Add(txtbox_qtd_produto15);
            Controls.Add(txtbox_qtd_produto14);
            Controls.Add(txtbox_qtd_produto13);
            Controls.Add(txtbox_qtd_produto12);
            Controls.Add(txtbox_qtd_produto11);
            Controls.Add(txtbox_qtd_produto10);
            Controls.Add(txtbox_qtd_produto09);
            Controls.Add(txtbox_qtd_produto08);
            Controls.Add(txtbox_qtd_produto07);
            Controls.Add(txtbox_qtd_produto06);
            Controls.Add(txtbox_qtd_produto05);
            Controls.Add(txtbox_qtd_produto04);
            Controls.Add(txtbox_qtd_produto03);
            Controls.Add(txtbox_qtd_produto02);
            Controls.Add(txtbox_qtd_produto01);
            Controls.Add(btn_CANCELAVENDA);
            Controls.Add(btn_NOVAVENDA);
            Controls.Add(txtbox_VENDA);
            Controls.Add(label1);
            Controls.Add(btn_produto11);
            Controls.Add(btn_produto12);
            Controls.Add(btn_produto13);
            Controls.Add(btn_produto14);
            Controls.Add(btn_produto15);
            Controls.Add(btn_produto16);
            Controls.Add(btn_produto17);
            Controls.Add(btn_produto18);
            Controls.Add(btn_produto19);
            Controls.Add(btn_produto20);
            Controls.Add(btn_produto10);
            Controls.Add(btn_produto09);
            Controls.Add(btn_produto08);
            Controls.Add(btn_produto07);
            Controls.Add(btn_produto06);
            Controls.Add(btn_produto05);
            Controls.Add(btn_produto04);
            Controls.Add(btn_produto03);
            Controls.Add(btn_produto02);
            Controls.Add(btn_produto01);
            Controls.Add(pnl_rodape);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormVendas";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            Load += FormVendas_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnl_rodape;
        private Button btn_produto01;
        private Button btn_produto02;
        private Button btn_produto03;
        private Button btn_produto04;
        private Button btn_produto05;
        private Button btn_produto06;
        private Button btn_produto07;
        private Button btn_produto08;
        private Button btn_produto09;
        private Button btn_produto10;
        private Button btn_produto11;
        private Button btn_produto12;
        private Button btn_produto13;
        private Button btn_produto14;
        private Button btn_produto15;
        private Button btn_produto16;
        private Button btn_produto17;
        private Button btn_produto18;
        private Button btn_produto19;
        private Button btn_produto20;
        private Label label1;
        private TextBox txtbox_VENDA;
        private Button btn_NOVAVENDA;
        private Button btn_CANCELAVENDA;
        private TextBox txtbox_qtd_produto01;
        private TextBox txtbox_qtd_produto02;
        private TextBox txtbox_qtd_produto03;
        private TextBox txtbox_qtd_produto04;
        private TextBox txtbox_qtd_produto05;
        private TextBox txtbox_qtd_produto06;
        private TextBox txtbox_qtd_produto07;
        private TextBox txtbox_qtd_produto08;
        private TextBox txtbox_qtd_produto09;
        private TextBox txtbox_qtd_produto10;
        private TextBox txtbox_qtd_produto20;
        private TextBox txtbox_qtd_produto19;
        private TextBox txtbox_qtd_produto18;
        private TextBox txtbox_qtd_produto17;
        private TextBox txtbox_qtd_produto16;
        private TextBox txtbox_qtd_produto15;
        private TextBox txtbox_qtd_produto14;
        private TextBox txtbox_qtd_produto13;
        private TextBox txtbox_qtd_produto12;
        private TextBox txtbox_qtd_produto11;
        private Button btn_GRAVARVENDA;
        private ListBox listBoxVenda;
        private TextBox txtbox_valor_produto10;
        private TextBox txtbox_valor_produto09;
        private TextBox txtbox_valor_produto08;
        private TextBox txtbox_valor_produto07;
        private TextBox txtbox_valor_produto06;
        private TextBox txtbox_valor_produto05;
        private TextBox txtbox_valor_produto04;
        private TextBox txtbox_valor_produto03;
        private TextBox txtbox_valor_produto02;
        private TextBox txtbox_valor_produto01;
        private TextBox txtbox_valor_produto20;
        private TextBox txtbox_valor_produto19;
        private TextBox txtbox_valor_produto18;
        private TextBox txtbox_valor_produto17;
        private TextBox txtbox_valor_produto16;
        private TextBox txtbox_valor_produto15;
        private TextBox txtbox_valor_produto14;
        private TextBox txtbox_valor_produto13;
        private TextBox txtbox_valor_produto12;
        private TextBox txtbox_valor_produto11;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label13;
        private Label label14;
        private Label label11;
        private Label label12;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private CheckBox checkBox_PIX;
        private CheckBox checkBox_CARTAO;
        private PictureBox pictureBox1;
        private TextBox textBox_Troco;
        private CheckBox checkBox_Dinheiro;
        private Label label3;
        private TextBox txtbox_DINHEIRO;
        private PictureBox pictureBox2;
        private GroupBox groupBox1;
        private Button btn_impressao;
        private PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Label label23;
        private TextBox textBox_TotalVenda;
        private Button btn_ApagarValorDinheiro;
        private Label label24;
        private TextBox txtValorPago;
        private Button btn_25_centavos;
        private Button btn_50_centavos;
        private Button btn_05_centavos;
        private Button btn_10_centavos;
        private Button btn_100reais;
        private Button btn_200reais;
        private Button btn_50reais;
        private Button btn_5reais;
        private Button btn_20reais;
        private Button btn_2reais;
        private Button btn_10reais;
        private Button btn_1real;
    }
}