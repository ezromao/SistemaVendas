﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SistemaVendas.Dados
{
    public class EnumProdutos
    {    
        public enum Produtos
        {
            [Display(Name = "Produto 01")]
            produto01,
            [Display(Name = "Produto 02")]
            produto02,
            [Display(Name = "Produto 03")]
            produto03,
            [Display(Name = "Produto 04")]
            produto04,
            [Display(Name = "Produto 05")]
            produto05,
            [Display(Name = "Produto 06")]
            produto06,
            [Display(Name = "Produto 07")]
            produto07,
            [Display(Name = "Produto 08")]
            produto08,
            [Display(Name = "Produto 09")]
            produto09,
            [Display(Name = "Produto 10")]
            produto10,
            [Display(Name = "Produto 11")]
            produto11,
            [Display(Name = "Produto 12")]
            produto12,
            [Display(Name = "Produto 13")]
            produto13,
            [Display(Name = "Produto 14")]
            produto14,
            [Display(Name = "Produto 15")]
            produto15,
            [Display(Name = "Produto 16")]
            produto16,
            [Display(Name = "Produto 17")]
            produto17,
            [Display(Name = "Produto 18")]
            produto18,
            [Display(Name = "Produto 19")]
            produto19,
            [Display(Name = "Produto 20")]
            produto20
        }
    }
}
